<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# Forrest Gump Timer Project Instructions

This is a comprehensive Python-based treadmill timer application that tracks a user's journey to complete Forrest Gump's epic run (3 years, 2 months, 14 days, 16 hours at 2.4 mph).

## Project Context
- Target: 15,248 miles over 6,353 hours
- Speed: Constant 2.4 mph (Forrest's pace)
- Features: GUI, web interface, Google Drive sync, progress visualization
- Start date: July 2025

## Code Guidelines
- Use clear, readable Python code with proper docstrings
- Follow PEP 8 style guidelines
- Implement proper error handling for API calls
- Use matplotlib/plotly for data visualization
- Structure code with clear separation of concerns
- Add comprehensive logging for debugging
- Ensure cross-platform compatibility (Windows focus)

## Key Components
1. Desktop GUI (tkinter) - Main interface
2. Web server (Flask) - Mobile access
3. Google Drive sync - Cloud backup
4. Progress tracking - Monthly graphs and statistics
5. Session management - Timer, breaks, data storage

## Data Format
- Sessions: Start/end times, running time, break time, distance, calories
- Monthly aggregation for graph visualization
- JSON and CSV export capabilities
- Google Sheets integration for cloud storage

When generating code, focus on user experience, data accuracy, and reliable synchronization between local and cloud storage.
